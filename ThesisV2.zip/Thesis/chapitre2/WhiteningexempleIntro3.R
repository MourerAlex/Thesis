
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)
library(Rmixmod)

options(digits=4, scipen =100)

source("fonctions/simu_p_q_d_2.R")
cbbPalette <- c("#000000","#56B4E9")

###############
# Fixing params
###############
# params skm
nstart = 10; iter.max = 250

# params simus
n = 300
p=2; d=0; p1=0; p2=0; q=0
mu_p = 5

# true clusters
prior=c(0.34, 0.33, 0.33)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)
mu3 = rep(0,p)

mu = rbind(mu1, mu2, mu3)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0.5
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}


###############
# Generate data 
###############

data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                              prior=prior, # vector: ratio of obs in each cluster
                              mu_p = mu,  # matrix: centers of clusters of the important variables
                              sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                              sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                              d = d, # integer: number of independent noise variables
                              scale=T,
                              p1 = p1,
                              p2 = p2,
                              seed = 42)

# dataset
dataset <- as.data.frame(data$dataset)
colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
# true clusters
Classes <- as.factor(data$trueclusters)

###############
# plotting data
###############

ggplot( dataset, aes(x=X1, y=X2, colour =  Classes)) + 
  geom_point(size = 2) +  theme_classic() +
  scale_colour_colorblind() + 
  ggtitle(label = "Exemple introductif - vraies classes", 
          subtitle = expression(paste("p"[K],"=1; ", "m=2; ", "cor(",bold(x)^2, ",", bold(x)^3,")=0.5"))) +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2))) +
  labs(colour="Vraies \nClasses")

###############
# standard Kmea
###############

## KMEANS
km <- kmeans(dataset, centers = 3,  nstart = 100, iter.max = 1000)
kmeans_cluster <- as.factor(km$cluster)

## Plots of the clustering
p1 <- ggplot( dataset, aes(x=X1, y=X2, colour =  kmeans_cluster)) + 
  geom_point(size = 2) +  theme_classic() + 
  scale_colour_colorblind()  +  
  ggtitle("Clustering avant blanchiment de Mahalanobis") +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2)))+
  labs(colour="Clusters\nKmeans")

###############
# ZCA results
###############

### ZCA tranformation
W <- whitening::whiteningMatrix(Sigma = var(dataset), method="ZCA")
Z <- as.matrix(dataset) %*% W
Z <- data.frame(Z)
colnames(Z) <- paste0("Z",seq(1, ncol(dataset)))

## KMEANS
km <- kmeans(Z, centers = 3,  nstart = 100, iter.max = 1000)
kmeans_cluster_zca <- as.factor(km$cluster)

## Plots of the clustering
p2 <- ggplot( Z, aes(x=Z1, y=Z2, colour =  kmeans_cluster_zca)) + 
  geom_point(size = 2) +  theme_classic() + 
  scale_colour_colorblind()  +  
  ggtitle("Clustering après blanchiment de Mahalanobis") +
  xlab(expression(paste(bold(y)^1)))+ylab(expression(paste(bold(y)^2)))+
  labs(colour="Clusters\nKmeans")


###############
# PLOT results
###############

## Plot arrange : 
grid.arrange(p1, p2, ncol=2)
