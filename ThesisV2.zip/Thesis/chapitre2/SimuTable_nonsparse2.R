
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)
library(Rmixmod)

options(digits=4, scipen =100)

source("fonctions/simu_p_q_d_2.R")

###############
# Fixing params
###############

n_simu = 10

# params km
nstart = 100; iter.max = 250

# params simus
n = 100
p=2; d=5; p1=0; p2=0; q=5
mu_p = 2

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0.9
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}

# table res
table_res <- matrix(NA, ncol = 6, nrow = n_simu)

# loop simu
for(i in 1:n_simu){
  
  print(paste("iteration=",i))
  ###############
  # Generate data 
  ###############
  
  data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                                prior=prior, # vector: ratio of obs in each cluster
                                mu_p = mu,  # matrix: centers of clusters of the important variables
                                sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                                sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                                d = d, # integer: number of independent noise variables
                                scale=T,
                                p1 = p1,
                                p2 = p2,
                                seed = i)
  
  # dataset
  dataset <- as.data.frame(data$dataset)
  colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
  # true clusters
  Classes <- as.integer(data$trueclusters)
  
  ###############
  # running kmean
  ###############
  
  km <- kmeans(x=dataset, centers=K, nstart=nstart, iter.max = iter.max)
  Clusters_km <- as.integer(km$cluster)
  
  ###############
  # running kmICS
  ###############
  
  w1 <- rowSums(cor(dataset)^2)
  w1 <- 1/sqrt(w1)
  Y <- sweep(dataset, 2, w1, FUN="*")
  km <- kmeans(x=Y, centers=K, nstart=nstart, iter.max = iter.max)
  Clusters_kmICS <- as.integer(km$cluster)
  
  ###############
  # running CAH 1
  ###############

  hc <- hclust(d=dist(dataset), "ward.D2")
  Clusters_cah <- cutree(hc, k = K)

  ###############
  # running CAHICs
  ###############

  hc_ICS <- hclust(d=dist(Y), "ward.D2")
  Clusters_cahICS <- cutree(hc_ICS, k = K)
  
  ###############
  # running GMM
  ###############
  
  # mixmodGaussianModel(family = c("general"), equal.proportions = T, free.proportions = F)
  model1 <- mixmodGaussianModel(listModels="Gaussian_p_L_C")
  mxcl <- mixmodCluster(dataset, nbCluster=K, 
                        models = model1,
                        strategy = new("Strategy", 
                                       algo = "EM",
                                       # nbIterationInAlgo = 400,
                                       # epsilonInAlgo = 1e-5,
                                       initMethod = "label", 
                                       labels = as.integer(Clusters_km)))
  Clusters_gmm_1 <- as.integer(mxcl@bestResult@partition)

  ###############
  # running GMM
  ###############
  
  all <- mixmodGaussianModel()
  mxcl <- mixmodCluster(dataset, nbCluster=K, 
                        models = all,
                        strategy = new("Strategy", 
                                       algo = "EM",
                                       # nbIterationInAlgo = 400,
                                       # epsilonInAlgo = 1e-5,
                                       initMethod = "label", 
                                       labels = as.integer(Clusters_km)))
  Clusters_gmm_all <- as.integer(mxcl@bestResult@partition)

  ###############
  # save results
  ###############
  table_res[i,] <- c( aricode::ARI(Clusters_km,Classes),
                      aricode::ARI(Clusters_kmICS,Classes),
                      aricode::ARI(Clusters_cah,Classes),
                      aricode::ARI(Clusters_cahICS,Classes),
                      aricode::ARI(Clusters_gmm_1,Classes),
                      aricode::ARI(Clusters_gmm_all,Classes)
                      )
}

###############
# table results
###############

table_sd <- apply(table_res,2,sd)
table_mean <- colMeans(table_res)

library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
xtable(data.frame(rbind(table_mean,table_sd)))

ggplot( dataset, aes(x=X1, y=X2, colour =  as.factor(Classes))) + 
  geom_point(size = 2.5) +  theme_classic() + ggtitle(paste0("True Clusters")) +
  scale_colour_colorblind()  + theme(legend.position = "none")
