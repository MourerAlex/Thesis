library(mvtnorm)

myseed <- 3
n <- 100
p <- 5
m <- 1
mu <- rep(0,p)

set.seed(myseed)
X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))

library(PCAmixdata)
pcamix <- PCAmix(X.quanti = X, ndim=p, graph = F)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

## plot 1 
p1<-ggplot(data = Y, aes(x=PC1, y=PC2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale et histogramme", subtitle = expression(paste("p"[K],"=5; ", "m=1"))) +
  scale_colour_colorblind()

library(ggExtra)
ggMarginal(p1,type = "density", margins = "x", size = 4)


## plot 2 
p <- 5
m <- 1.7
mu <- rep(0,p)

set.seed(myseed)
X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))

library(PCAmixdata)
pcamix <- PCAmix(X.quanti = X, ndim=p, graph = F)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

p2<-ggplot(data = Y, aes(x=PC1, y=PC2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale et histogramme", subtitle = expression(paste("p"[K],"=5; ", "m=1.7"))) +
  scale_colour_colorblind()

ggMarginal(p2,type = "density", margins = "x", size = 4)


## plot 3 
p <- 50
m <- 0.6
mu <- rep(0,p)

set.seed(myseed)
X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))

library(PCAmixdata)
pcamix <- PCAmix(X.quanti = X, ndim=p, graph = F)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

p3<-ggplot(data = Y, aes(x=PC1, y=PC2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale et histogramme", subtitle = expression(paste("p"[K],"=50; ", "m=0.6"))) +
  scale_colour_colorblind()

ggMarginal(p3,type = "density", margins = "x", size = 4)


## plot 4
p <- 50
m <- 1.7
mu <- rep(0,p)

set.seed(myseed)
X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))

library(PCAmixdata)
pcamix <- PCAmix(X.quanti = X, ndim=p, graph = F)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

p4<-ggplot(data = Y, aes(x=PC1, y=PC2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale et histogramme", subtitle = expression(paste("p"[K],"=50; ", "m=1.7"))) +
  scale_colour_colorblind()

ggMarginal(p4,type = "density", margins = "x", size = 4)

