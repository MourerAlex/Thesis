library(mvtnorm)

n <- 100
p <- 5
m <- 0.6
mu <- rep(0,p)

X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))
colnames(X) <- paste0("x",1:p)

v1 <- diag(var(X))


m <- 1

X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))
colnames(X) <- paste0("x",1:p)

v2 <- diag(var(X))



m <- 1.7

X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))
colnames(X) <- paste0("x",1:p)

v3 <- diag(var(X))


library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
xtable(data.frame(rbind(v1,v2,v3)))
