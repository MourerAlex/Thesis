

library(vimpclust)

data(HDdata)
out <- sparsewkm(X = HDdata[,-14], centers = 2)
plot(out)
plot(out, "expl.var")
lambda.select <- data.frame(expvar=apply(out$bss.per.feature,2,sum)/dim(out$Wm)[1], lambda=out$lambda)
find.cpt(lambda.select$expvar)
changepoint::cpt.meanvar(lambda.select$expvar,class=TRUE)@cpts[1]
detect_rupture(lambda.select$expvar)

plot(out, "w.expl.var")
bss <- sapply(1:length(out$lambda), function(i){sum(out$Wm[,i]*out$bss.per.feature[,i])})/apply(out$Wm,2,sum)
data.to.plot <- data.frame(bss, lambda=out$lambda)
find.cpt(data.to.plot$bss)
detect_rupture(data.to.plot$bss)

