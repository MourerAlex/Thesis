
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)

options(digits=4, scipen =100)

source("fonctions/simu_p_q_d_2.R")
source("fonctions/changepoint.R")
source("fonctions/detect_rupture.R")
source("fonctions/ARI_bench_mixtes.R")
source("fonctions/swkm2.R")

cbbPalette <- c("#000000","#56B4E9")


###############
# Fixing params
###############

# params skm
nstart = 10; iter.max = 250
nlambda = 10;

# seed
seeds_sim = 0

# params simu
n_simu = 10
n = 100

p=10; d=100; p1=0; p2=0; q=0
mu_p = 0.7

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}


###############
# Generate data 
###############

data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                              prior=prior, # vector: ratio of obs in each cluster
                              mu_p = mu,  # matrix: centers of clusters of the important variables
                              sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                              sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                              d = d, # integer: number of independent noise variables
                              scale=F,
                              p1 = p1,
                              p2 = p2,
                              seed = 42)

# dataset
dataset <- as.data.frame(data$dataset)
for(j in (p/2+1):p){
  dataset[,j] <-  as.factor(ifelse(dataset[,j]>0,1,0))
}

for(j in (p+1):(p+1+d/2)){
  dataset[,j] <- as.factor(ifelse(dataset[,j]>0,1,0))
}

colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
# true clusters
true_clusters <- as.factor(data$trueclusters)

###############
# plotting data
###############

ggplot( dataset, aes(x=X1, y=X2, colour =  true_clusters)) + 
  geom_point(size = 2.5) +  theme_classic() + ggtitle(paste0("True Clusters")) +
  scale_colour_colorblind()  + theme(legend.position = "none")

###############
# verifications
###############

library(PCAmixdata)
spdata <- splitmix(dataset[,1:p])
pcamix <- PCAmix(X.quanti = spdata$X.quanti, spdata$X.quali, ndim=p, graph = F, rename.level=TRUE)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

## plot 1 
pltpca <-ggplot(data = Y, aes(x=PC1, y=PC2, color = true_clusters )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale et histogramme", subtitle = expression(paste("p"[K],"=10; ", "m=1.7"))) +
  scale_colour_manual(values=cbbPalette)

library(ggExtra)
ggMarginal(pltpca,type = "density", margins = "x", size = 4)


###############
# running simus
###############
# Sparsekmeans run on normalised data
res_simu <- simu_SKM_SGMM_mixtes_bench(n_simu=n_simu, n=n, prior=prior, mu=mu, 
                                sigma=sigma, sigma_noise=sigma_noise, d=d, p1=p1, p2=p2,
                                nstart=nstart, iter.max=iter.max)

###############
# plotting resu
###############
saveRDS(res_simu, file="Introduction/rds/res_simu_mixtes_2.rds")
b <- res_simu
b[1] <- c(
  "SWKM_chgpt",
  "VarSelLCM"
)

dataplot <- data.frame(b)

## table
library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
tab <- dataplot[order(dataplot$me_ARI, decreasing = T),-c(8,10)]
colnames(tab) <- c(
                   "noms",
                   "m_ARI",
                   "sd_ARI",
                   "m_rimp",
                   "sd_rimp",
                   "m_rb",
                   "sd_rb",
                   "m_t",
                   "sd_t"
                  )
print(xtable(tab, align = rep("l",10)), include.rownames=FALSE)


