

fit = hill_climb(dataset, k=K, nperms=25, nbins=50, itermax = 20, threshold=0)            
