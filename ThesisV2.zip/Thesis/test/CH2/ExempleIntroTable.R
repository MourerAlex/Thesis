
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)
library(Rmixmod)

options(digits=4, scipen =100)

source("fonctions/simu_p_q_d_2.R")

###############
# Fixing params
###############

n_simu = 100

# params km
nstart = 10; iter.max = 250

# params simus
n = 300
p=1; d=0; p1=0; p2=0; q=2
mu_p = 2

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0.9
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}

# table res
table_res <- matrix(NA, ncol = 4, nrow = n_simu)
table_time <- matrix(NA, ncol = 4, nrow = n_simu)

# loop simu
for(i in 1:n_simu){
  
  time_methods <- c(); inc <- 1
  print(paste("iteration=",i))
  ###############
  # Generate data 
  ###############
  
  data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                                prior=prior, # vector: ratio of obs in each cluster
                                mu_p = mu,  # matrix: centers of clusters of the important variables
                                sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                                sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                                d = d, # integer: number of independent noise variables
                                scale=T,
                                p1 = p1,
                                p2 = p2,
                                seed = i)
  
  # dataset
  dataset <- as.data.frame(data$dataset)
  colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
  # true clusters
  Classes <- as.integer(data$trueclusters)
  
  ###############
  # running kmean
  ###############
  
  start_time <- Sys.time()
  km <- kmeans(x=dataset, centers=K, nstart=nstart, iter.max = iter.max)
  Clusters_km <- as.integer(km$cluster)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ###############
  # running kmICS
  ###############
  
  start_time <- Sys.time()
  w1 <- rowSums(cor(dataset)^2)
  w1 <- 1/sqrt(w1)
  Y <- sweep(dataset, 2, w1, FUN="*")
  km <- kmeans(x=Y, centers=K, nstart=nstart, iter.max = iter.max)
  Clusters_kmICS <- as.integer(km$cluster)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ###############
  # running gmm
  ###############
  
  start_time <- Sys.time()
  mxcl <- mixmodCluster(dataset, nbCluster=K, 
                        strategy = new("Strategy", 
                                       algo = "EM",
                                       # nbIterationInAlgo = 400,
                                       # epsilonInAlgo = 1e-5,
                                       initMethod = "label", 
                                       labels = as.integer(Clusters_km)))
  Clusters_gmm <- as.integer(mxcl@bestResult@partition)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ###############
  # running Mclus
  ###############
  
  start_time <- Sys.time()
  mod1 <- Mclust(data = dataset, G = K, verbose=F)
  # Auto
  mclust_auto <- as.integer(mod1$classification)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ###############
  # save results
  ###############
  table_res[i,] <- c( aricode::ARI(Clusters_km,Classes),
                      aricode::ARI(Clusters_kmICS,Classes),
                      aricode::ARI(Clusters_gmm,Classes),
                      aricode::ARI(mclust_auto,Classes)
                      )
  table_time[i,] <- time_methods

}

###############
# table results
###############

table_ari_sd <- apply(table_res,2,sd)
table_ari_mean <- colMeans(table_res)

table_time_sd <- apply(table_time,2,sd)
table_time_mean <- colMeans(table_time)


library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
xtable(data.frame(rbind(table_mean, table_sd, 
                        table_time_mean, table_time_sd)))


