
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)

options(digits=4, scipen =100)

source("fonctions/simu_p_q_d_2.R")
source("fonctions/changepoint.R")
source("fonctions/detect_rupture.R")
source("fonctions/ARI_bench_ics_test.R")


###############
# Fixing params
###############

# params skm
nstart = 10; iter.max = 250
nlambda = 10;

# seed
seeds_sim = 0

# params simu
n_simu = 2
n = 100

p=10; d=100; p1=0; p2=0; q=0
mu_p = 0.85

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0.7
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}

###############
# running simus
###############
# Sparsekmeans run on normalised data
res_simu <- simu_SKM_SGMM_bench(n_simu=n_simu, n=n, prior=prior, mu=mu, sigma=sigma, sigma_noise=sigma_noise, d=d, p1=p1, p2=p2, nstart=nstart, iter.max=iter.max)

###############
# plotting resu
###############
saveRDS(res_simu, file="chapitre2/rds/res_simu_test.rds")

b <- res_simu
## ARI 

dataplot <- data.frame(b)
dataplot <- dataplot[order(dataplot$me_ARI, decreasing = F),]

plt0 <- ggplot(dataplot, aes(x=reorder(name, me_ARI, FUN=mean, deacreasing = T), y=me_ARI, colour=name)) +
  geom_errorbar(aes(ymin=pmax(me_ARI-sd_ARI,rep(0,nrow(dataplot))), ymax=pmin(me_ARI+sd_ARI,rep(1,nrow(dataplot))) ), width=.2) + 
  # geom_hline(yintercept = max(dataplot$me_ARI), col="black", lwd=0.5, lty=2)+
  geom_line() +  geom_point() + theme_classic() + coord_flip()+theme(legend.position = "none")+
  ggtitle("Comparaison des méthodes avec l'ARI") + 
          # subtitle = paste0(n_simu," simulations - p=", p, " ; q =", q, "; d=", d," ; p1=", p1, "; p2=", p2)) + 
  xlab("") + ylab("ARI") +  scale_y_continuous(breaks = seq(0,1,by=0.1)) + scale_color_colorblind()


## RATIO IMP VAR 
dataplot <- data.frame(b)
dataplot <- dataplot[order(dataplot$me_ARI, decreasing = F),]

plt1 <- ggplot(dataplot, aes(x=reorder(name, me_ARI, FUN=mean, deacreasing = T), y=me_rs_VI, colour=name)) +
  geom_errorbar(aes(ymin=pmax(me_rs_VI-sd_rs_VI,rep(0,nrow(dataplot))), ymax=pmin(me_rs_VI+sd_rs_VI,rep(1,nrow(dataplot)))), width=.2) + 
  geom_line() +  geom_point() + theme_classic() + coord_flip()+
  ggtitle("Ratio des variables importantes sélectionnées") + theme(legend.position = "none") + 
  xlab("") + ylab("ratio") +  scale_y_continuous(breaks = seq(0,1,by=0.1)) + scale_color_colorblind()

## RATIO NOISE VAR 
dataplot <- data.frame(b)
dataplot <- dataplot[order(dataplot$me_ARI, decreasing = F),]

plt2 <- ggplot(dataplot, aes(x=reorder(name, me_ARI, FUN=mean, deacreasing = F), y=me_rs_N, colour=name)) +
  geom_errorbar(aes(ymin=pmax(me_rs_N-sd_rs_N,rep(0,nrow(dataplot))), ymax=pmin(me_rs_N+sd_rs_N,rep(1,nrow(dataplot)))), width=.2) + 
  geom_line() +  geom_point() + theme_classic() + coord_flip()+
  ggtitle("Ratio des variables de bruit sélectionnées") + theme(legend.position = "none") + 
  xlab("") + ylab("ratio") +  scale_y_continuous(breaks = seq(0,1,by=0.1)) + scale_color_colorblind()

## TIME
dataplot <- data.frame(b)
dataplot <- dataplot[order(dataplot$me_ARI, decreasing = F),]

plt3 <- ggplot(dataplot, aes(x=reorder(name, me_ARI, FUN=mean, deacreasing = F), y=me_time_n, colour=name)) +
  geom_errorbar(aes(ymin=pmax(me_time_n-sd_time_n,rep(0,nrow(dataplot))), ymax=me_time_n+sd_time_n), width=.2) + 
  geom_line() +  geom_point() + theme_classic() + coord_flip()+
  ggtitle("Comparaison du temps de calcul") + theme(legend.position = "none") + 
  xlab("") + ylab("temps en secondes") + scale_color_colorblind()

## GRID
plt0
plt1
plt2
plt3

## table
library(xtable)
options(xtable.floating = FALSE)
options(xtable.timestamp = "")
tab <- dataplot[order(dataplot$me_ARI, decreasing = T),-c(8,9)]
colnames(tab) <- c("noms",
                   "m_ARI",
                   "sd_ARI",
                   "m_rimp",
                   "sd_rimp",
                   "m_rb",
                   "sd_rb",
                   "m_t",
                   "sd_t"
                  )
print(xtable(tab, align = rep("l",10)), include.rownames=FALSE)
