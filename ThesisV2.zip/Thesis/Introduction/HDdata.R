library(vimpclust)
library(PCAmixdata)

X <- splitmix(HDdata[,-14])
pcamix <- PCAmix(X.quanti = X$X.quanti, X.quali = X$X.quali, rename.level = T, ndim = 13)

library(ggplot2)
library(ggthemes)

Y <- data.frame(pcamix$ind$coord[,1:2])
colnames(Y) <- c("PC1", "PC2")

ggplot(data = Y, aes(x=PC1, y=PC2, color = HDdata$HD )) + geom_point(size=2) + theme_classic() + 
  ggtitle(label = "Les données HDdata", subtitle = "Deux premières composantes principales d'une ACP de données mixtes") +
  labs(color = "Maladie\nCardiaque") + xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  scale_colour_colorblind()




Y <- data.frame(pcamix$ind$coord[,1:13])
colnames(Y) <- paste0("PC",1:13)

library(GGally)
ggpairs(Y, aes(colour = HDdata$HD, alpha = 0.4))+ theme_classic()

  