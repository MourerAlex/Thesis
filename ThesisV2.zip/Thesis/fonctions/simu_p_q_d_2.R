# # num obs
# n <- 500
# 
# # true clusters
# p = 1
# prior=c(0.5, 0.5)
# mu1 = rep(0,p)
# mu2 = rep(7,p)
# 
# mu = rbind(mu1, mu2)
# sigma = diag(rep(1,p))
# K = nrow(mu)
# 
# # noisy correlated
# q = 2
# cor = 0.5
# sigma_noise = diag(rep(1-cor,q))+cor
# 
# # noisy inde
# d=0
# # 
# sim <- simu_clustering_p_q_d(n=n,
#                       prior=prior,
#                       mu_p = mu_p,
#                       sigma = sigma,
#                       sigma_noise = sigma_noise,
#                       d = d
#                       )
# 
# cor(sim$X)
# a = sim$X
# kmeans(a, centers = 2)

simu_clustering_p_q_d <- function(n, # integer: number of obs
                                  prior, # vector: ratio of obs in each cluster
                                  mu_p, # matrix: centers of clusters of important variables
                                  sigma = diag(rep(1,p)), # matrix: matrix of variance covariance of the true variables
                                  # g = 1, # integer: number of groups of correlated noise variables
                                  # mu_q = rep(0,q), # vector: centers of correlated noise variables. If g>1, a list of centers of each group.
                                  sigma_noise = NULL, # matrix: matrix of variance covariance of the correlated noise variables.  If g>1, a list of covariance of each group.
                                  d = 0, # integer: number of independent noise variables
                                  # mu_d = 0, # real or vector:  centers of independent noise variables; 
                                  # var_d = 1, # real or vector: variance of independent noise variables; 
                                  # center = T, # boolean: variables are centered
                                  scale = T, # boolean: variables are normalized to unit variance
                                  # variables are automatically scaled
                                  p1,
                                  p2,
                                  seed = 42
                                  )
{

  library(mvtnorm)

  p <- ncol(mu_p)
  K <- nrow(mu_p) # number of clusters
  Y <- rep(NA,n) # true clusters
  set.seed(seed)
  U <- runif(n) 
  b <- cumsum(prior)

  if( p == 0){
    stop("Must provide data with p>0.")
  }
  if(is.null(sigma_noise)){
    sigma_noise = matrix(NA,0,0)
    q <- 0 # number of correlated noise variables
  }

  if(q+d == 0){ # If there is no noise variables 
    mu_p_q_d <- mu_p
    
    sigma_p_q_d <- matrix(0, nrow = p+q+d, ncol = p+q+d)
    sigma_p_q_d[1:p,1:p] <- sigma
    
  } else if(q == 0){ # If there is no correlated noise variables 
    mu_d <- matrix(0, nrow = K, ncol = d) # noise variables have 0 mean: the data is scaled at the end of the function
    mu_p_q_d <- cbind(mu_p, mu_d)     # create the clusters centers
    
    sigma_p_q_d <- matrix(0, nrow = p+d, ncol = p+d)  # create the covariance matrix
    sigma_p_q_d[1:p,1:p] <- sigma
    # noise variables have unit variance: the data is scaled at the end of the function
    sigma_p_q_d[(p+1):(p+d), (p+1):(p+d)] <- diag(rep(1,d))
    
  } else if(d == 0){ # If there is no independent noise variables 
    mu_q <- matrix(0, nrow = K, ncol = q) # noise variables have 0 mean: data is scaled to 0 mean and unit variance at the end
    mu_p_q_d <- cbind(mu_p, mu_q)     # create the clusters centers

    sigma_p_q_d <- matrix(0, nrow = p+q+d, ncol = p+q+d)
    sigma_p_q_d[1:p,1:p] <- sigma
    sigma_p_q_d[(p+1):(p+q), (p+1):(p+q)] <- sigma_noise

  } else {
    # noise variables have 0 mean: the data is scaled at the end of the function
    mu_q <- matrix(0, nrow = K, ncol = q)
    mu_d <- matrix(0, nrow = K, ncol = d)
    # create the clusters centers
    mu_p_q_d <- cbind(mu_p, mu_q, mu_d)
    
    sigma_p_q_d <- matrix(0, nrow = p+q+d, ncol = p+q+d) # create the covariance matrix
    sigma_p_q_d[1:p,1:p] <- sigma
    sigma_p_q_d[(p+1):(p+q), (p+1):(p+q)] <- sigma_noise
    # noise variables have unit variance: the data is scaled at the end of the function
    sigma_p_q_d[(p+q+1):(p+q+d), (p+q+1):(p+q+d)] <- diag(rep(1,d))
  } 
  
  # create the data matrix
  X <-  matrix(NA, nrow = n, ncol = p+q+d+p1+p2)
  set.seed(seed)
  
  for(i in 1:n) 
  {
    for (k in 1:K)
    {
      if (U[i] < b[k]) {
        if(p+q+d == 1){ # if there is only one variable: univariate gaussian
          X[i] <- rnorm(1, mu_p_q_d[k], as.integer(sigma_p_q_d))
        } else{  # multivariate guassian
          X[i,1:c(p+q+d)] <- rmvnorm(1, mu_p_q_d[k,], sigma_p_q_d)
          if(p1!=0){
            for(t in 1:p1){
              X[i,p+q+d+t] <- 0.65*X[i,1] + rnorm(1, 0, 0.37)
            }
          }
          if(p2!=0){
            for(t in 1:p2){
              X[i,p+q+d++p1+t] <- 0.65*X[i,2] + rnorm(1, 0, 0.37)
            }
          }
        }
        Y[i] <- k # target 
        break
      }
    }
  }
  
  if(scale){
    X <- data.frame(scale(X, T, T)) # scale data to 0 mean and unit variance
  }
  return(list(dataset=X, trueclusters=Y))
}

