

fun_count_p1 <- function(x, p1){
  whx <- ifelse(x!=0,1,0)
  return( sum(whx[1:p1])/p1  )
}


fun_count_qd <- function(x, p1){
  whx <- ifelse(x!=0,1,0)
  return( sum(whx[(p1+1):length(x)])/length((p1+1):length(x))  )
}

ARI_res_skm_sgmm_mixtes <- function(seeds_i, dataset, true_clusters, K, nstart, iter.max)
{
  library(vimpclust)
  library(VarSelLCM)

  hsize = ncol(dataset)
  inc = 1
  
  ari_name <- c(
    "SWKM_chgpt_norm",
    "VLCM"
  )
  
  time_methods <- c()
  
  ## Sparse KMEANs
  set.seed(seeds_i)
  start_time <- Sys.time()
  swkmW_norm <- sparsewkm_2(X = dataset, centers = K, nlambda = 10,
                                     nstart = nstart, itermaxw = 10, itermaxkm = iter.max,
                                     verbose = 0, epsilonw = 1e-04)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ari_tab_norm <-c()
  for(i in 1:10){
    ari_tab_norm[i] <- aricode::ARI(true_clusters, swkmW_norm$cluster[,i])
  }
  # lambda.select <- data.frame(bss=apply(swkmW_norm$bss.per.feature,2,sum)/dim(swkmW_norm$W)[1], lambda=swkmW_norm$lambda)
  # bss <- sapply(1:length(swkmW_norm$lambda), function(i){sum(swkmW_norm$Wm[,i]*swkmW_norm$bss.per.feature[,i])})/apply(swkmW_norm$Wm,2,sum)
  # lambda.select <- data.frame(bss, lambda=swkmW_norm$lambda)
  bss <- sapply(1:length(swkmW_norm$lambda), function(i){sum(swkmW_norm$Wm[,i]*swkmW_norm$bss.per.feature[,i])})/apply(swkmW_norm$Wm,2,sum)
  lambda.select <- data.frame(bss, lambda=swkmW_norm$lambda)
  
  ## VarSelLCM
  start_time <- Sys.time()
  VLCM_all <- VarSelCluster(x = dataset, gvals = K, nbcores=40, crit.varsel = "BIC", vbleSelec = TRUE)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ## ARI
  ARI_vec <- c(
    aricode::ARI(swkmW_norm$cluster[,find.cpt(lambda.select$bss)], true_clusters),
    # aricode::ARI(swkmW_norm$cluster[,detect_rupture(lambda.select$bss)], true_clusters),

    aricode::ARI(fitted(VLCM_all), true_clusters)
  )

  ## K chosen
  K_chose <- c(
    K,
    length(unique(fitted(VLCM_all)))
  )
  
  ## Var IMP chosen
  SEL_imp <- c(
    fun_count_p1(swkmW_norm$W[,find.cpt(lambda.select$bss)],p),
    # fun_count_p1(swkmW_norm$W[,detect_rupture(lambda.select$bss)],p),
    
    fun_count_p1(as.integer(colnames(dataset) %in% VLCM_all@model@names.relevant),p)
  )
  
  ## Var noise chosen
  SEL_noise <- c(
    fun_count_qd(swkmW_norm$W[,find.cpt(lambda.select$bss)],p),
    # fun_count_qd(swkmW_norm$W[,detect_rupture(lambda.select$bss)],p),
    
    fun_count_qd(as.integer(colnames(dataset) %in% VLCM_all@model@names.relevant),p)
  )
  
  return( data.frame(name=ari_name, ARI=ARI_vec, ratio_VI_sel = SEL_imp, ratio_noise_sel = SEL_noise, K=K_chose, time = time_methods, time_n = time_methods/min(time_methods)) )
}




simu_SKM_SGMM_mixtes_bench <- function(n_simu, n, prior, mu, sigma, sigma_noise, d, p1=0, p2=0, nstart, iter.max){
  library(gtools)
  mat_sd_ari <- matrix(0, ncol = 2, nrow = n_simu)
  mat_sd_selVI <- matrix(0, ncol = 2, nrow = n_simu)
  mat_sd_selN <- matrix(0, ncol = 2, nrow = n_simu)
  mat_sd_time <- matrix(0, ncol = 2, nrow = n_simu)
  
  for( seeds_i in 1:n_simu){
    print(paste0("it=",seeds_i))
    data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                                  prior=prior, # vector: ratio of obs in each cluster
                                  mu_p = mu,  # matrix: centers of clusters of the important variables
                                  sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                                  sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                                  d = d, # integer: number of independent noise variables
                                  scale=F,
                                  p1 = p1,
                                  p2 = p2,
                                  seed = seeds_i)
    
    # dataset
    dataset <- as.data.frame(data$dataset)
    for(j in (p/2+1):p){
      dataset[,j] <-  as.factor(ifelse(dataset[,j]>0,1,0))
      # dataset[,j] <- as.factor(quantcut(dataset[,j], q = 4))
    }
    
    for(j in (p+1):(p+1+d/2)){
      dataset[,j] <- as.factor(ifelse(dataset[,j]>0,1,0))
      # dataset[,j] <- as.factor(quantcut(dataset[,j], q = 4))
    }
    
    colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
    # true clusters
    true_clusters <- as.factor(data$trueclusters)
    K_1 <- length(unique(true_clusters)) 
    
    if(seeds_i == 1){
      A <- ARI_res_skm_sgmm_mixtes(seeds_i = seeds_i, dataset = dataset, true_clusters=true_clusters, K=K, nstart = nstart, iter.max = iter.max)
      mat_sd_ari[1,] <- A[,2]
      mat_sd_selVI[1,] <- A[,3]
      mat_sd_selN[1,]  <- A[,4]
      mat_sd_time[1,] <- A[,6]
    } else {
      B <- ARI_res_skm_sgmm_mixtes(seeds_i = seeds_i, dataset = dataset, true_clusters=true_clusters, K=K, nstart = nstart, iter.max = iter.max)[,2:ncol(A)]
      A[,2:ncol(A)] <- A[,2:ncol(A)] + B
      mat_sd_ari[seeds_i,] <- B[,1]
      mat_sd_selVI[seeds_i,] <- B[,2]
      mat_sd_selN[seeds_i,]  <- B[,3]
      mat_sd_time[seeds_i,]  <- B[,5]
    }
  }
  
  
  return(
    data.frame(name = A[,1],
               me_ARI = A[,2]/n_simu, sd_ARI = apply(mat_sd_ari,2,sd), 
               me_rs_VI = A[,3]/n_simu, sd_rs_VI = apply(mat_sd_selVI,2,sd), 
               me_rs_N = A[,4]/n_simu, sd_rs_N = apply(mat_sd_selN,2,sd), 
               K=A[,5]/n_simu, me_time = A[,6]/n_simu,
               me_time_n = A[,7]/n_simu, sd_time = apply(mat_sd_time,2,sd)
    )
  )
}

