

fun_count_p1 <- function(x, p1){
  whx <- ifelse(x!=0,1,0)
  return( sum(whx[1:p1])/p1  )
}


fun_count_qd <- function(x, p1){
  whx <- ifelse(x!=0,1,0)
  return( sum(whx[(p1+1):length(x)])/length((p1+1):length(x))  )
}

ARI_res_skm_sgmm3 <- function(seeds_i, dataset, true_clusters, K, nstart, iter.max, search.clustvarsel = "greedy")
{
  library(FisherEM)
  library(vimpclust)
  library(SelvarMix)
  library(VarSelLCM)
  library(vscc)
  library(clustvarsel)
  library(sparcl)
  
  hsize = ncol(dataset)
  inc = 1
  
  ari_name <- c(
    "Kmeans_norm",
    
    "Kmeans_ICS",
    
    "GMM_true",
    
    "GMM_ALL"
  )
  
  time_methods <- c()
  
  ## Sparse KMEANS NORM
  Z <- as.data.frame(scale(dataset, T, T))
  set.seed(seeds_i)
  start_time <- Sys.time()
  swkmW_norm <- vimpclust::groupsparsewkm(X = Z, centers = K, nlambda = 10,
                                     nstart = nstart, itermaxw = 10, itermaxkm = iter.max,
                                     scaling = F, verbose = 0, epsilonw = 1e-04)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ari_tab_norm <-c()
  for(i in 1:10){
    ari_tab_norm[i] <- aricode::ARI(true_clusters, swkmW_norm$cluster[,i])
  }
  lambda.select <- data.frame(bss=apply(swkmW_norm$bss.per.feature,2,sum)/dim(swkmW_norm$W)[1], lambda=swkmW_norm$lambda)
  
  ## SPARCL DW RT
  start_time <- Sys.time()
  km.perm <- KMeansSparseCluster.permute(x = Z, K=K, nvals=10, nperms=25, silent = T)
  km.out <- KMeansSparseCluster(x = Z, K=K, wbounds=km.perm$bestw)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ## Sparse KMEANS NORM ICS
  w1 <- rowSums(cor(Z)^2)
  w1 <- 1/sqrt(w1)
  Y <- sweep(Z, 2, w1, FUN="*")
  set.seed(seeds_i)
  start_time <- Sys.time()
  swkmW_ICS <- vimpclust::groupsparsewkm(X = Y, centers = K, nlambda = 10,
                                          nstart = nstart, itermaxw = 10, itermaxkm = iter.max,
                                          scaling = F, verbose = 0, epsilonw = 1e-04)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ari_tab_norm <-c()
  for(i in 1:10){
    ari_tab_norm[i] <- aricode::ARI(true_clusters, swkmW_ICS$cluster[,i])
  }
  lambda.select_ICS <- data.frame(bss=apply(swkmW_ICS$bss.per.feature,2,sum)/dim(swkmW_ICS$W)[1], lambda=swkmW_ICS$lambda)
  
  ## SPARCL DW RT ICS
  start_time <- Sys.time()
  km.perm_ICS <- KMeansSparseCluster.permute(x = Y, K=K, nvals=10, nperms=25, silent = T)
  km.out_ICS <- KMeansSparseCluster(x = Y, K=K, wbounds=km.perm_ICS$bestw)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ## VarSelLCM
  start_time <- Sys.time()
  VLCM_all <- VarSelCluster(x = dataset, gvals = K, nbcores=40, crit.varsel = "BIC", vbleSelec = TRUE)
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1
  
  ## vscc
  start_time <- Sys.time()
  vscc_o_norm <- vscc(x = Y, G=K, automate = "mclust")
  end_time <- Sys.time()
  time_methods[inc] <- end_time - start_time; inc = inc+1


  ## ARI
  ARI_vec <- c(
    # aricode::ARI(swkmW_norm$cluster[,find.cpt(lambda.select$bss)], true_clusters),
    aricode::ARI(swkmW_norm$cluster[,detect_rupture(lambda.select$bss)], true_clusters),
    
    aricode::ARI(km.out[[1]]$Cs, true_clusters),
    
    aricode::ARI(swkmW_ICS$cluster[,detect_rupture(lambda.select_ICS$bss)], true_clusters),
    
    aricode::ARI(km.out_ICS[[1]]$Cs, true_clusters),

    aricode::ARI(fitted(VLCM_all), true_clusters),

    aricode::ARI(vscc_o_norm$bestmodel$classification, true_clusters)
    
  )

  ## K chosen
  K_chose <- c(
    K,
    
    length(unique(km.out[[1]]$Cs)),
    
    K,
    
    length(unique(km.out_ICS[[1]]$Cs)),

    length(unique(fitted(VLCM_all))),

    length(unique(vscc_o_norm$bestmodel$classification))
      )
  
  ## Var IMP chosen
  SEL_imp <- c(
    # fun_count_p1(swkmW_norm$W[,find.cpt(lambda.select$bss)],p),
    fun_count_p1(swkmW_norm$W[,detect_rupture(lambda.select$bss)],p),
    
    fun_count_p1(km.out[[1]]$ws,p),
    
    fun_count_p1(swkmW_ICS$W[,detect_rupture(lambda.select_ICS$bss)],p),
    
    fun_count_p1(km.out_ICS[[1]]$ws,p),

    fun_count_p1(as.integer(colnames(dataset) %in% VLCM_all@model@names.relevant),p),

    fun_count_p1(as.integer(colnames(dataset) %in% rownames(vscc_o_norm$bestmodel$parameters$mean)),p)
  )
  
  ## Var noise chosen
  SEL_noise <- c(
    # fun_count_qd(swkmW_norm$W[,find.cpt(lambda.select$bss)],p),
    fun_count_qd(swkmW_norm$W[,detect_rupture(lambda.select$bss)],p),
    
    fun_count_qd(km.out[[1]]$ws,p),
    
    fun_count_qd(swkmW_ICS$W[,detect_rupture(lambda.select_ICS$bss)],p),
    
    fun_count_qd(km.out_ICS[[1]]$ws,p),

    fun_count_qd(as.integer(colnames(dataset) %in% VLCM_all@model@names.relevant),p),

    fun_count_qd(as.integer(colnames(dataset) %in% rownames(vscc_o_norm$bestmodel$parameters$mean)),p)
  )
  
  return( data.frame(name=ari_name, ARI=ARI_vec, ratio_VI_sel = SEL_imp, ratio_noise_sel = SEL_noise, K=K_chose, time = time_methods, time_n = time_methods/min(time_methods)) )
}




simu_SKM_SGMM_bench <- function(n_simu, n, prior, mu, sigma, sigma_noise, d, p1=0, p2=0, nstart, iter.max, search.clustvarsel = "greedy"){
  
  mat_sd_ari <- matrix(0, ncol = 6, nrow = n_simu)
  mat_sd_selVI <- matrix(0, ncol = 6, nrow = n_simu)
  mat_sd_selN <- matrix(0, ncol = 6, nrow = n_simu)
  mat_sd_time <- matrix(0, ncol = 6, nrow = n_simu)
  
  for( seeds_i in 1:n_simu){
    print(paste0("it=",seeds_i))
    data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                                  prior=prior, # vector: ratio of obs in each cluster
                                  mu_p = mu,  # matrix: centers of clusters of the important variables
                                  sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                                  sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                                  d = d, # integer: number of independent noise variables
                                  scale=F,
                                  p1 = p1,
                                  p2 = p2,
                                  seed = seeds_i)
    
    # dataset
    dataset <- as.data.frame(data$dataset)
    colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
    # true clusters
    true_clusters <- as.factor(data$trueclusters)
    K_1 <- length(unique(true_clusters)) 
    
    if(seeds_i == 1){
      A <- ARI_res_skm_sgmm3(seeds_i = seeds_i, dataset = dataset, true_clusters=true_clusters, K=K, nstart = nstart, iter.max = iter.max, search.clustvarsel=search.clustvarsel)
      mat_sd_ari[1,] <- A[,2]
      mat_sd_selVI[1,] <- A[,3]
      mat_sd_selN[1,]  <- A[,4]
      mat_sd_time[1,] <- A[,6]
    } else {
      B <- ARI_res_skm_sgmm3(seeds_i = seeds_i, dataset = dataset, true_clusters=true_clusters, K=K, nstart = nstart, iter.max = iter.max, search.clustvarsel=search.clustvarsel)[,2:ncol(A)]
      A[,2:ncol(A)] <- A[,2:ncol(A)] + B
      mat_sd_ari[seeds_i,] <- B[,1]
      mat_sd_selVI[seeds_i,] <- B[,2]
      mat_sd_selN[seeds_i,]  <- B[,3]
      mat_sd_time[seeds_i,]  <- B[,5]
    }
  }
  
  
  return(
    data.frame(name = A[,1],
               me_ARI = A[,2]/n_simu, sd_ARI = apply(mat_sd_ari,2,sd), 
               me_rs_VI = A[,3]/n_simu, sd_rs_VI = apply(mat_sd_selVI,2,sd), 
               me_rs_N = A[,4]/n_simu, sd_rs_N = apply(mat_sd_selN,2,sd), 
               K=A[,5]/n_simu, me_time = A[,6]/n_simu,
               me_time_n = A[,7]/n_simu, sd_time_n = apply(mat_sd_time,2,sd)
    )
  )
}

