
library(MASS)
library(ggplot2)
library(Polychrome)
library(grid)
library(gridExtra)
library(ggthemes)
library(aricode)

options(digits=4, scipen =100)
cbbPalette <- c("#000000","#56B4E9")

source("fonctions/simu_p_q_d_2.R")

##############################
######### Scénario 1 #########
##############################

###############
# Fixing params
###############

# params skm
nstart = 10; iter.max = 250
nlambda = 10;

# seed
seeds_sim = 0

# params simu
n_simu = 20
n = 100

p=2; d=25; p1=0; p2=0; q=0
mu_p = 1.5

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}


###############
# Generate data 
###############

data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                              prior=prior, # vector: ratio of obs in each cluster
                              mu_p = mu,  # matrix: centers of clusters of the important variables
                              sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                              sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                              d = d, # integer: number of independent noise variables
                              scale=F,
                              p1 = p1,
                              p2 = p2,
                              seed = 42)

# dataset
dataset <- as.data.frame(data$dataset)
colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
# true clusters
Classes <- as.factor(data$trueclusters)

###############
# plotting data
###############

ggplot( dataset, aes(x=X1, y=X2, colour =  Classes)) + 
  geom_point(size = 2) +  theme_classic() + 
  ggtitle(label = "Vérification du Scénario 1", subtitle = expression(paste("p"[K],"=2; ", "m=1.5"))) +
  scale_colour_manual(values=cbbPalette) +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2)))


##############################
######### Scénario 2 #########
##############################

###############
# Fixing params
###############

# params simu
n = 100

p=10; d=100; p1=0; p2=0; q=0
mu_p = 0.8

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}


###############
# Generate data 
###############

data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                              prior=prior, # vector: ratio of obs in each cluster
                              mu_p = mu,  # matrix: centers of clusters of the important variables
                              sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                              sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                              d = d, # integer: number of independent noise variables
                              scale=F,
                              p1 = p1,
                              p2 = p2,
                              seed = 42)

# dataset
dataset <- as.data.frame(data$dataset)
colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
# true clusters
true_clusters <- as.factor(data$trueclusters)

###############
# plotting data
###############

ggplot( dataset, aes(x=X1, y=X2, colour =  true_clusters)) + 
  geom_point(size = 2.5) +  theme_classic() + ggtitle(paste0("True Clusters")) +
  scale_colour_colorblind()  + theme(legend.position = "none")
