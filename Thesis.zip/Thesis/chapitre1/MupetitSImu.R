library(mvtnorm)

n <- 100
p <- 5
m <- 1
mu <- rep(0,p)

X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, mu-m, diag(rep(1,p)))
))

Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))
colnames(X) <- paste0("x",1:p)

ggplot(data = X, aes(x=x1, y=x2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  ggtitle(label = "Mélange de deux Gaussiennes", subtitle = "Répresentation des données sur les deux premières variables") +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2)))+
  scale_colour_colorblind()

library(PCAmixdata)
pcamix <- PCAmix(X.quanti = X, ndim=p, graph = F)
Y <- data.frame(pcamix$ind$coord[,1:p])
colnames(Y) <- paste0("PC",1:p)

ggplot(data = Y, aes(x=PC1, y=PC2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première composante principale") +  ylab("Deuxième composante principale") +
  ggtitle(label = "Analyse en composante principale", subtitle = "Répresentation des données sur les deux premières composantes principales") +
  scale_colour_colorblind()

ggplot(data = Y, aes(x=PC1)) + theme_classic() +
  geom_histogram(aes(y=..density..), colour="black", fill="white", bins = 25)+
  geom_density(alpha=.2, fill="#56B4E9")  + scale_colour_colorblind() + 
  xlab("Première composante principale") + 
  ggtitle(label = "Histogramme des données", 
          subtitle = "Représentatition de la répartition sur la première composante principale")


library(tsne)
tsn <- tsne(X, epoch=100)

Y <- data.frame(tsn)
colnames(Y) <- paste0("tsne",1:2)

ggplot(data = Y, aes(x=tsne1, y=tsne2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  xlab("Première dimension") +  ylab("Deuxième dimension") +
  ggtitle(label = "t-SNE", subtitle = "Répresentation des données sur deux dimensions") +
  scale_colour_colorblind()



