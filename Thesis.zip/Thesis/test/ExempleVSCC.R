library(mvtnorm)

n <- 100
p <- 2
m <- 50
mu <- rep(0,p)

X<- data.frame(rbind(
  rmvnorm(n, mu, diag(rep(1,p))),
  rmvnorm(n, mu+m, diag(rep(1,p))),
  rmvnorm(n, c(m,0.6*m), diag(rep(1,p)))
))
X <- data.frame(scale(X, T, T))
Classes <- as.factor(c(rep(1,n),rep(2,n),rep(3,n)))
colnames(X) <- paste0("x",1:p)

ggplot(data = X, aes(x=x1, y=x2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  ggtitle(label = "Mélange de trois Gaussiennes", subtitle = expression(paste("cor(",bold(x)^1,",",bold(x)^2,")=0.91, ", v^1, "/n=0.017, ", v^2, "/n=0.16"))) +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2)))+
  scale_colour_colorblind()

cor(X)
km <- kmeans(X, centers=3)
vimpclust::weightedss(X=X, cl=km$cluster)$wss.per.feature/nrow(X)

library(vscc)
resvscc <- vscc(X)
resvscc$selected
