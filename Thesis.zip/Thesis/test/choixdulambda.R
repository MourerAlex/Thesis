
source("fonctions/simu_p_q_d_2.R")
source("fonctions/changepoint.R")
source("fonctions/ARI_bench.R")

###############
# Fixing params
###############

# params skm
nstart = 10; iter.max = 250
nlambda = 10;

# seed
seeds_sim = 0

# params simu
n_simu = 10
n = 100

p=10; d=100; p1=0; p2=0; q=0
mu_p = 0.85

# true clusters
prior=c(0.5, 0.5)
mu1 = rep(-mu_p,p)
mu2 = rep(mu_p,p)

mu = rbind(mu1, mu2)
sigma = diag(rep(1,p))
K = nrow(mu)

# noisy correlated
cor = 0
if( q == 0){
  sigma_noise = NULL
} else{
  sigma_noise = diag(rep(1-cor,q))+cor
}


###############
# Generate data 
###############

data <- simu_clustering_p_q_d(n=n, # integer: number of obs
                              prior=prior, # vector: ratio of obs in each cluster
                              mu_p = mu,  # matrix: centers of clusters of the important variables
                              sigma = sigma,  # matrix: matrix of variance covariance of the important variables
                              sigma_noise = sigma_noise, # matrix: matrix of variance covariance of the correlated noise variables
                              d = d, # integer: number of independent noise variables
                              scale=F,
                              p1 = p1,
                              p2 = p2,
                              seed = 42)

# dataset
dataset <- as.data.frame(data$dataset)
colnames(dataset) <- paste0("X", 1:ncol(dataset)) 
# true clusters
true_clusters <- as.factor(data$trueclusters)


out <- groupsparsewkm(X = dataset, centers = 2, nlambda = 20)
plot(out, showlegend = F)
plot(out, "expl.var")
lambda.select <- data.frame(expvar=apply(out$bss.per.feature,2,sum)/dim(out$W)[1], lambda=out$lambda)
find.cpt(lambda.select$expvar)
changepoint::cpt.meanvar(lambda.select$expvar,class=TRUE)@cpts[1]
detect_rupture(lambda.select$expvar)

plot(out, "w.expl.var")
bss <- sapply(1:length(out$lambda), function(i){sum(out$W[,i]*out$bss.per.feature[,i])})/apply(out$W,2,sum)
data.to.plot <- data.frame(bss, lambda=out$lambda)
find.cpt(data.to.plot$bss)
detect_rupture(data.to.plot$bss)

