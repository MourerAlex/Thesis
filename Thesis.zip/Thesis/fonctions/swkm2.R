library(vimpclust)
sparsewkm_2 <- function(X, centers, lambda = NULL, nlambda = 20, nstart = 10, 
                      itermaxw = 20, itermaxkm = 10, renamelevel = TRUE, 
                      verbose = 1, epsilonw = 1e-04) 
{
  call <- match.call()
  
  Xrec <- recodmix(X, T)
  Z <- scale(Xrec$Z, T, T)
  res.out <- groupsparsewkm(X = Z, centers, lambda, nlambda, index = Xrec$index, sizegroup = T,  nstart, 
                            itermaxw, itermaxkm, scaling = FALSE, verbose, epsilonw) 
  # scaling is put to FALSE because recodmix already scales the variables
  rownames(res.out$Wg) <- c(names(Xrec$X)[sapply(Xrec$X,is.factor)==F], names(Xrec$X)[sapply(Xrec$X,is.factor)==T])
  res <- list(call = res.out$call, type="MixedSparse",  W = res.out$Wg,
              Wm = res.out$W, cluster = res.out$cluster, lambda = res.out$lambda, 
              sel.init.feat=res.out$sel.groups,
              sel.trans.feat=res.out$sel.feat,
              X.transformed = Xrec$Z, index = Xrec$index, bss.per.feature = res.out$bss.per.feature)
  class(res) <- "spwkm"
  return(res)
}
