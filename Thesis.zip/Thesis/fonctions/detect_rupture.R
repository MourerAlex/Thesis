
detect_rupture <- function(x){
  x <- as.vector(x)
  if(length(unique(x)) == 1){
    return(length(x))
  } else{
    
    rupture <- c()
    for(i in 1:(length(x)-1) ){
      rupture[i] <- abs(x[i]-x[i+1])
    }
    
    return(which.max(rupture))
  }
}