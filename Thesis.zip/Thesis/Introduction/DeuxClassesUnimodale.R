library(mvtnorm)

n <- 300

X <- data.frame(rmvnorm(n, c(0,0), diag(c(0.1,0.1))+0.9)) 
colnames(X) <- c("x1", "x2")
km <- kmeans(x=X, 2)
Classes <- as.factor(km$cluster)

ggplot(data = X, aes(x=x1, y=x2, color = Classes )) + geom_point(size=2) + theme_classic() + 
  ggtitle(label = "Gaussienne corrélée en deux dimensions", subtitle = "Classes linéairement séparables mais la distribution est unimodale") +
  xlab(expression(paste(bold(x)^1)))+ylab(expression(paste(bold(x)^2)))+
  scale_colour_colorblind()
